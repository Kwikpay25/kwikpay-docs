# Brand Identity

**Slogan:** *Work hard. Get paid Kwik.*

**Primary Colors:**
- Yellow/Orange — Energy and innovation.
- Dark Gray/Black — Stability and trust.

**Typography:** Inter / Poppins / Manrope

**Logo Concept:**  
A modern **“K”** symbol with motion or lightning streak — representing speed, trust, and progress.
