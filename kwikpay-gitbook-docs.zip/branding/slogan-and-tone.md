# Slogan & Brand Voice

**Slogan:**  
> *Work hard. Get paid Kwik.*

**Tone of Voice:**
- Clear
- Fast
- Empowering
- Human-centered

KwikPay’s voice communicates confidence and innovation — reflecting speed, transparency, and reliability.
