# License

© 2025 KwikPay. All rights reserved.  
KwikPay is a decentralized initiative led by the KwikPay community and contributors.
