# Contact & Links

| Platform | Link |
|-----------|------|
| 🌐 Website | [kwikpay.gitbook.io](#) |
| 🐦 X (Twitter) | [@KwikPayHQ](#) |
| 💼 LinkedIn | [KwikPay Official](#) |
| 📧 Email | kwikpay.global@gmail.com |
