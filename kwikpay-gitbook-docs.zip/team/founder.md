# Team

## Founder
**Samson Bamidele Gabriel**  
Founder & Product Visionary  
Nigeria  

Driven by a passion for technology and financial inclusion, Samson leads KwikPay’s vision to empower freelancers through blockchain-based instant payments.
