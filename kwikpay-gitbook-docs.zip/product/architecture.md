# Product Architecture

KwikPay integrates blockchain innovation with simplicity.

**Components:**
- **Frontend:** Mobile-first dApp interface.  
- **Backend:** Smart contracts on KUBChain testnet.  
- **Wallet:** MetaMask and compatible Web3 wallets.

**Payment Flow:**
1. Client deposits crypto into escrow.  
2. Freelancer completes the task.  
3. Upon approval, funds are released automatically.
