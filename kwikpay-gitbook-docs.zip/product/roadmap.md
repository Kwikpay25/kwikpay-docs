# Roadmap (2025–2026)

| Quarter | Milestone |
|----------|------------|
| Q1 2025 | Concept design and documentation |
| Q2 2025 | UI/UX prototype in Figma |
| Q3 2025 | Smart contract on KUBChain testnet |
| Q4 2025 | Beta testing and community launch |
| Q1 2026 | Mainnet release and scaling |
